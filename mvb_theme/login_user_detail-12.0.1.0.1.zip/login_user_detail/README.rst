User Log Details v11
====================

This module developed to  record  login details of user.

Installation
============

Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

Nothing to configure.

Credits
=======

Developer: Saritha @ cybrosys

