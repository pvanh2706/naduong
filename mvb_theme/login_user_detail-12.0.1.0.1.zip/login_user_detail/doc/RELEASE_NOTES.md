## Module <login_user_detail>

#### 27.02.2019
#### Version 12.0.1.0.0
#### ADD
- Initial Commit

#### 27.06.2019
#### Version 12.0.1.0.1
#### FIX
- Bug Fixed
