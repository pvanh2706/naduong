`2.9.0`
-------

- Temporary attachments

`2.8.0`
-------

- Added path field widgets

`2.7.0`
-------

- Added color index field widget

`2.6.0`
-------

- Moved editor features to separate module

`2.5.0`
-------

- Added color field widget

`2.4.0`
-------

- Added widget to share binary fields

`2.3.0`
-------

- Added custom colors to snippet options

`2.2.0`
-------

- Added widget to share text fields

`2.1.0`
-------

- Automatic labels on settings

`2.0.0`
-------

- Migrated to Python 3

`1.0.0`
-------

- Init version
